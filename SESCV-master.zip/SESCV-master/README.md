# SESCV
My version of a resume class - alternative formating for a basic resume inspired by AltaCV 

# SESCV - Example
![example_resume](https://user-images.githubusercontent.com/37937240/38324782-286a8898-3839-11e8-8234-c9b6b8130569.png)
